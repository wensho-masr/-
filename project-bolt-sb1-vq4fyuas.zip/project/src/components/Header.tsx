import React from 'react';
import { Book, Headphones, Clock, Compass, FileText, Home } from 'lucide-react';
import Logo from './Logo';

interface HeaderProps {
  currentPage: string;
  setCurrentPage: (page: string) => void;
  darkMode: boolean;
}

const Header: React.FC<HeaderProps> = ({ currentPage, setCurrentPage, darkMode }) => {
  const navItems = [
    { id: 'home', label: 'Home', icon: <Home className="h-5 w-5" /> },
    { id: 'quran', label: 'Quran', icon: <Book className="h-5 w-5" /> },
    { id: 'audio', label: 'Audio', icon: <Headphones className="h-5 w-5" /> },
    { id: 'prayer-times', label: 'Prayer Times', icon: <Clock className="h-5 w-5" /> },
    { id: 'adhkar', label: 'Adhkar', icon: <FileText className="h-5 w-5" /> },
    { id: 'qibla', label: 'Qibla', icon: <Compass className="h-5 w-5" /> },
  ];

  return (
    <header className={`sticky top-0 z-40 w-full ${darkMode ? 'bg-gray-800 text-white' : 'bg-white text-gray-800'} shadow-md`}>
      <div className="container mx-auto px-4 py-4 flex flex-col md:flex-row items-center justify-between">
        <div className="flex items-center mb-4 md:mb-0">
          <Logo className="h-10 w-10 text-emerald-600 dark:text-emerald-400" />
          <span className="ml-2 text-xl font-bold">IslamicHub</span>
        </div>

        <nav className="w-full md:w-auto">
          <ul className="flex flex-wrap justify-center items-center space-x-1 md:space-x-2">
            {navItems.map((item) => (
              <li key={item.id}>
                <button
                  onClick={() => setCurrentPage(item.id)}
                  className={`flex items-center px-3 py-2 rounded-md text-sm transition-colors ${
                    currentPage === item.id
                      ? 'bg-emerald-600 text-white'
                      : `${darkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-100'}`
                  }`}
                  aria-current={currentPage === item.id ? 'page' : undefined}
                >
                  <span className="mr-1.5">{item.icon}</span>
                  <span>{item.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;
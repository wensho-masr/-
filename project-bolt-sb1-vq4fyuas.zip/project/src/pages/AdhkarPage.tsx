import React, { useState } from 'react';
import { Sun, Moon, RefreshCw, Check, Clock } from 'lucide-react';

const AdhkarPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'morning' | 'evening'>('morning');
  const [completedAdhkar, setCompletedAdhkar] = useState<number[]>([]);

  // Sample adhkar data - would come from API or database in production
  const morningAdhkar = [
    {
      id: 1,
      arabic: 'اللَّهُ لاَ إِلَهَ إِلاَّ هُوَ الْحَيُّ الْقَيُّومُ لاَ تَأْخُذُهُ سِنَةٌ وَلاَ نَوْمٌ...',
      translation: 'Allah! There is no god but He, the Living, the Self-subsisting, Eternal...',
      source: 'Ayatul Kursi (2:255)',
      count: 1,
      virtue: 'Whoever recites this in the morning will be protected until evening.',
    },
    {
      id: 2,
      arabic: 'قُلْ هُوَ اللَّهُ أَحَدٌ، اللَّهُ الصَّمَدُ، لَمْ يَلِدْ وَلَمْ يُولَدْ، وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ',
      translation: 'Say, "He is Allah, [who is] One, Allah, the Eternal Refuge. He neither begets nor is born, Nor is there to Him any equivalent."',
      source: 'Surah Al-Ikhlas (112:1-4)',
      count: 3,
      virtue: 'Whoever recites this three times in the morning will be protected from all evil.',
    },
    {
      id: 3,
      arabic: 'أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لاَ إِلَـهَ إِلاَّ اللهُ وَحْدَهُ لاَ شَرِيكَ لَهُ...',
      translation: 'We have reached the morning and at this very time all sovereignty belongs to Allah. All praise is for Allah. None has the right to be worshipped except Allah alone...',
      source: 'Reported by Abu Dawud',
      count: 1,
      virtue: 'Whoever says this with conviction in the morning and dies that day will enter Paradise.',
    },
  ];

  const eveningAdhkar = [
    {
      id: 4,
      arabic: 'أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لاَ إِلَـهَ إِلاَّ اللهُ وَحْدَهُ لاَ شَرِيكَ لَهُ...',
      translation: 'We have reached the evening and at this very time all sovereignty belongs to Allah. All praise is for Allah. None has the right to be worshipped except Allah alone...',
      source: 'Reported by Abu Dawud',
      count: 1,
      virtue: 'Whoever says this with conviction in the evening and dies that night will enter Paradise.',
    },
    {
      id: 5,
      arabic: 'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا',
      translation: 'In Your name, O Allah, I die and I live.',
      source: 'Reported by Al-Bukhari',
      count: 1,
      virtue: 'Whoever says this when going to bed is protected through the night.',
    },
    {
      id: 6,
      arabic: 'اللَّهُمَّ قِنِي عَذَابَكَ يَوْمَ تَبْعَثُ عِبَادَكَ',
      translation: 'O Allah, protect me from Your punishment on the Day You resurrect Your servants.',
      source: 'Reported by Abu Dawud',
      count: 3,
      virtue: 'Whoever says this three times when going to bed, Allah will protect them from punishment on the Day of Resurrection.',
    },
  ];

  const toggleAdhkarCompletion = (id: number) => {
    if (completedAdhkar.includes(id)) {
      setCompletedAdhkar(completedAdhkar.filter(itemId => itemId !== id));
    } else {
      setCompletedAdhkar([...completedAdhkar, id]);
    }
  };

  const resetCompletedAdhkar = () => {
    setCompletedAdhkar([]);
  };

  const renderAdhkarList = (adhkarList: typeof morningAdhkar) => {
    return (
      <div className="space-y-6">
        {adhkarList.map((dhikr) => (
          <div 
            key={dhikr.id} 
            className={`bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 border-l-4 transition-colors ${
              completedAdhkar.includes(dhikr.id)
                ? 'border-green-500 bg-green-50 dark:bg-green-900/10'
                : 'border-amber-500'
            }`}
          >
            <div className="flex justify-between">
              <div className="flex items-start space-x-2">
                <button 
                  className={`mt-1 h-6 w-6 rounded-full flex items-center justify-center border transition-colors ${
                    completedAdhkar.includes(dhikr.id)
                      ? 'border-green-500 bg-green-500 text-white'
                      : 'border-gray-300 dark:border-gray-600'
                  }`}
                  onClick={() => toggleAdhkarCompletion(dhikr.id)}
                  aria-label={completedAdhkar.includes(dhikr.id) ? "Mark as incomplete" : "Mark as complete"}
                >
                  {completedAdhkar.includes(dhikr.id) && <Check className="h-4 w-4" />}
                </button>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200">
                  {dhikr.count}x
                </span>
              </div>
              <span className="text-sm text-gray-500 dark:text-gray-400">
                {dhikr.source}
              </span>
            </div>
            
            <p 
              dir="rtl" 
              className="mt-4 text-xl font-arabic leading-relaxed text-right dark:text-white"
            >
              {dhikr.arabic}
            </p>
            
            <p className="mt-2 text-gray-700 dark:text-gray-300">
              {dhikr.translation}
            </p>
            
            <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
              <p className="text-sm text-gray-600 dark:text-gray-400 flex items-start">
                <span className="text-amber-600 dark:text-amber-400 mr-2">Virtue:</span>
                {dhikr.virtue}
              </p>
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 text-center dark:text-white">
        Daily Adhkar
      </h1>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden mb-8">
        <div className="flex border-b border-gray-200 dark:border-gray-700">
          <button
            className={`flex-1 py-4 px-6 text-center font-medium transition-colors ${
              activeTab === 'morning'
                ? 'bg-amber-500 text-white'
                : 'hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-white'
            }`}
            onClick={() => setActiveTab('morning')}
          >
            <div className="flex items-center justify-center">
              <Sun className="h-5 w-5 mr-2" />
              Morning Adhkar
            </div>
          </button>
          <button
            className={`flex-1 py-4 px-6 text-center font-medium transition-colors ${
              activeTab === 'evening'
                ? 'bg-indigo-600 text-white'
                : 'hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-white'
            }`}
            onClick={() => setActiveTab('evening')}
          >
            <div className="flex items-center justify-center">
              <Moon className="h-5 w-5 mr-2" />
              Evening Adhkar
            </div>
          </button>
        </div>
        
        <div className="p-6 bg-gray-50 dark:bg-gray-800">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center space-x-1">
              <Clock className="h-5 w-5 text-gray-600 dark:text-gray-300" />
              <h2 className="text-xl font-bold dark:text-white">
                {activeTab === 'morning' ? 'After Fajr until Sunrise' : 'After Asr until Maghrib'}
              </h2>
            </div>
            <button
              className="flex items-center px-3 py-1.5 text-sm bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 rounded-md transition-colors dark:text-white"
              onClick={resetCompletedAdhkar}
            >
              <RefreshCw className="h-4 w-4 mr-1.5" />
              Reset
            </button>
          </div>
          
          <div className="flex justify-between items-center p-3 bg-gray-100 dark:bg-gray-700 rounded-md mb-6">
            <span className="text-sm font-medium dark:text-white">
              Completed: {completedAdhkar.filter(id => 
                activeTab === 'morning' 
                  ? morningAdhkar.some(dhikr => dhikr.id === id)
                  : eveningAdhkar.some(dhikr => dhikr.id === id)
              ).length} / {activeTab === 'morning' ? morningAdhkar.length : eveningAdhkar.length}
            </span>
            <div className="w-32 h-2 bg-gray-200 dark:bg-gray-600 rounded-full overflow-hidden">
              <div 
                className={`h-full ${activeTab === 'morning' ? 'bg-amber-500' : 'bg-indigo-600'}`}
                style={{ 
                  width: `${(completedAdhkar.filter(id => 
                    activeTab === 'morning' 
                      ? morningAdhkar.some(dhikr => dhikr.id === id)
                      : eveningAdhkar.some(dhikr => dhikr.id === id)
                  ).length / (activeTab === 'morning' ? morningAdhkar.length : eveningAdhkar.length)) * 100}%` 
                }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {activeTab === 'morning' ? renderAdhkarList(morningAdhkar) : renderAdhkarList(eveningAdhkar)}

      <div className="mt-10 bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <h2 className="text-xl font-bold mb-4 dark:text-white">
          Benefits of Daily Adhkar
        </h2>
        <ul className="space-y-3 text-gray-700 dark:text-gray-300">
          <li className="flex">
            <span className="text-emerald-600 dark:text-emerald-400 mr-2">•</span>
            Protection from harm and evil
          </li>
          <li className="flex">
            <span className="text-emerald-600 dark:text-emerald-400 mr-2">•</span>
            Peace and tranquility in the heart
          </li>
          <li className="flex">
            <span className="text-emerald-600 dark:text-emerald-400 mr-2">•</span>
            Strengthens connection with Allah
          </li>
          <li className="flex">
            <span className="text-emerald-600 dark:text-emerald-400 mr-2">•</span>
            Helps in maintaining constant remembrance of Allah
          </li>
          <li className="flex">
            <span className="text-emerald-600 dark:text-emerald-400 mr-2">•</span>
            Shields against anxiety and depression
          </li>
        </ul>
      </div>
    </div>
  );
};

export default AdhkarPage;
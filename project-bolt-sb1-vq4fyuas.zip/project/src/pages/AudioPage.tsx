import React, { useState } from 'react';
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX } from 'lucide-react';

const AudioPage: React.FC = () => {
  const [currentQari, setCurrentQari] = useState<string | null>(null);
  const [currentSurah, setCurrentSurah] = useState<any | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(80);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);

  // Example qaris data
  const qaris = [
    { id: 'mishari', name: 'Mishari Rashid al-Afasy', style: 'Murattal' },
    { id: 'sudais', name: 'Abdurrahman As-Sudais', style: 'Murattal' },
    { id: 'minshawi', name: 'Mohamed Siddiq El-Minshawi', style: 'Murattal' },
    { id: 'husary', name: 'Mahmoud Khalil Al-Husary', style: 'Murattal' },
    { id: 'abdulbasit', name: 'Abdul Basit Abdus Samad', style: 'Murattal' },
  ];

  // Example surahs data - would be fetched from API in production
  const surahs = [
    { id: 1, name: 'Al-Fatihah', arabicName: 'الفاتحة', verses: 7 },
    { id: 2, name: 'Al-Baqarah', arabicName: 'البقرة', verses: 286 },
    { id: 3, name: 'Aali Imran', arabicName: 'آل عمران', verses: 200 },
    { id: 4, name: 'An-Nisa', arabicName: 'النساء', verses: 176 },
    { id: 5, name: 'Al-Ma\'idah', arabicName: 'المائدة', verses: 120 },
  ];

  const handlePlayPause = () => {
    if (!currentSurah) return;
    setIsPlaying(!isPlaying);
    // Audio control logic would go here
  };

  const handleQariSelect = (qariId: string) => {
    setCurrentQari(qariId);
    setIsPlaying(false);
    setProgress(0);
  };

  const handleSurahSelect = (surah: any) => {
    if (!currentQari) return;
    
    setCurrentSurah(surah);
    setIsPlaying(true);
    setProgress(0);
    // Audio loading and playing logic would go here
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseInt(e.target.value);
    setVolume(newVolume);
    setIsMuted(newVolume === 0);
    // Volume control logic would go here
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
    // Mute control logic would go here
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 text-center dark:text-white">
        Audio Quran
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Qaris Selection */}
        <div className="lg:col-span-3">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h2 className="text-xl font-bold mb-4 dark:text-white">Reciters</h2>
            <div className="space-y-2">
              {qaris.map((qari) => (
                <button
                  key={qari.id}
                  className={`w-full text-left p-3 rounded-md transition-colors ${
                    currentQari === qari.id 
                      ? 'bg-emerald-600 text-white' 
                      : 'bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 dark:text-white'
                  }`}
                  onClick={() => handleQariSelect(qari.id)}
                >
                  <p className="font-medium">{qari.name}</p>
                  <p className="text-sm opacity-80">{qari.style}</p>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-9">
          {/* Player */}
          <div className={`bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-8 ${!currentSurah ? 'opacity-50' : ''}`}>
            <div className="flex flex-col md:flex-row items-center justify-between mb-6">
              <div className="text-center md:text-left mb-4 md:mb-0">
                <h3 className="text-2xl font-bold dark:text-white">
                  {currentSurah ? currentSurah.name : 'Select a Surah'}
                </h3>
                <p className="text-gray-600 dark:text-gray-300">
                  {currentQari ? qaris.find(q => q.id === currentQari)?.name : 'Select a Reciter'}
                </p>
              </div>
              <div className="flex items-center space-x-4">
                <button className="text-gray-700 dark:text-gray-300 hover:text-emerald-600 dark:hover:text-emerald-400">
                  <SkipBack className="h-6 w-6" />
                </button>
                <button 
                  className={`rounded-full p-3 ${
                    isPlaying ? 'bg-red-500 hover:bg-red-600' : 'bg-emerald-600 hover:bg-emerald-700'
                  } text-white`}
                  onClick={handlePlayPause}
                  disabled={!currentSurah}
                >
                  {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
                </button>
                <button className="text-gray-700 dark:text-gray-300 hover:text-emerald-600 dark:hover:text-emerald-400">
                  <SkipForward className="h-6 w-6" />
                </button>
              </div>
            </div>

            <div className="mb-6">
              <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded-full">
                <div 
                  className="h-2 bg-emerald-600 rounded-full"
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
              <div className="flex justify-between text-sm mt-2 text-gray-600 dark:text-gray-300">
                <span>0:00</span>
                <span>0:00</span>
              </div>
            </div>

            <div className="flex items-center">
              <button 
                className="text-gray-700 dark:text-gray-300 mr-2"
                onClick={toggleMute}
              >
                {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
              </button>
              <input
                type="range"
                min="0"
                max="100"
                value={volume}
                onChange={handleVolumeChange}
                className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full appearance-none"
              />
            </div>
          </div>

          {/* Surah List */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h2 className="text-xl font-bold mb-4 dark:text-white">Surahs</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {surahs.map((surah) => (
                <button
                  key={surah.id}
                  className={`p-4 rounded-md text-left transition-colors ${
                    currentSurah?.id === surah.id
                      ? 'bg-emerald-100 dark:bg-emerald-900/20'
                      : 'bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600'
                  } ${!currentQari ? 'opacity-50 cursor-not-allowed' : ''} dark:text-white`}
                  onClick={() => currentQari && handleSurahSelect(surah)}
                  disabled={!currentQari}
                >
                  <div className="flex justify-between items-start mb-1">
                    <span className="bg-emerald-600 text-white w-6 h-6 rounded-full flex items-center justify-center text-sm">
                      {surah.id}
                    </span>
                    <span className="text-lg font-arabic">{surah.arabicName}</span>
                  </div>
                  <p className="font-medium">{surah.name}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-300">{surah.verses} verses</p>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AudioPage;
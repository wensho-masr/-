import React from 'react';
import { Book, Clock, Headphones, Compass, FileText } from 'lucide-react';

interface HomePageProps {
  setCurrentPage: (page: string) => void;
}

const HomePage: React.FC<HomePageProps> = ({ setCurrentPage }) => {
  const features = [
    {
      id: 'quran',
      title: 'Quran',
      description: 'Read the complete Quran with translations and tafsir',
      icon: <Book className="h-10 w-10 text-emerald-600" />,
    },
    {
      id: 'audio',
      title: 'Audio Quran',
      description: 'Listen to beautiful recitations from renowned Qaris',
      icon: <Headphones className="h-10 w-10 text-emerald-600" />,
    },
    {
      id: 'prayer-times',
      title: 'Prayer Times',
      description: 'Get accurate prayer times based on your location',
      icon: <Clock className="h-10 w-10 text-emerald-600" />,
    },
    {
      id: 'adhkar',
      title: 'Daily Adhkar',
      description: 'Morning and evening remembrances and supplications',
      icon: <FileText className="h-10 w-10 text-emerald-600" />,
    },
    {
      id: 'qibla',
      title: 'Qibla Finder',
      description: 'Find the direction of the Qibla from anywhere',
      icon: <Compass className="h-10 w-10 text-emerald-600" />,
    },
  ];

  const handleDailyHadith = () => {
    // This would fetch the hadith of the day
    alert('Hadith of the Day feature will be implemented in the next update.');
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Hero Section */}
      <section className="relative h-[500px] rounded-lg overflow-hidden mb-12">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: "url('https://images.pexels.com/photos/2179687/pexels-photo-2179687.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')" }}
        ></div>
        <div className="absolute inset-0 bg-black bg-opacity-60"></div>
        <div className="relative h-full flex flex-col justify-center items-center text-center px-4">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Welcome to IslamicHub
          </h1>
          <p className="text-xl text-white mb-8 max-w-2xl">
            Your comprehensive resource for Quran, audio recitations,
            prayer times, and Islamic guidance.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <button
              onClick={() => setCurrentPage('quran')}
              className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 transition-colors text-white rounded-md font-medium"
            >
              Read Quran
            </button>
            <button
              onClick={() => setCurrentPage('prayer-times')}
              className="px-6 py-3 bg-amber-600 hover:bg-amber-700 transition-colors text-white rounded-md font-medium"
            >
              Prayer Times
            </button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="mb-12">
        <h2 className="text-3xl font-bold text-center mb-8 dark:text-white">
          Features
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature) => (
            <div
              key={feature.id}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow cursor-pointer"
              onClick={() => setCurrentPage(feature.id)}
            >
              <div className="mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold mb-2 dark:text-white">{feature.title}</h3>
              <p className="text-gray-600 dark:text-gray-300">{feature.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Hadith of the Day */}
      <section className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-12">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold dark:text-white">Hadith of the Day</h2>
          <button 
            onClick={handleDailyHadith}
            className="text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 dark:hover:text-emerald-300 text-sm font-medium"
          >
            Refresh
          </button>
        </div>
        <blockquote className="border-l-4 border-emerald-600 pl-4 py-2 italic dark:text-white">
          Abu Huraira reported: The Messenger of Allah, peace and blessings be upon him, said, 
          "Whoever believes in Allah and the Last Day, let him speak goodness or remain silent."
        </blockquote>
        <p className="text-right mt-2 text-gray-600 dark:text-gray-300">
          Source: Sahih Al-Bukhari, Sahih Muslim
        </p>
      </section>
    </div>
  );
};

export default HomePage;
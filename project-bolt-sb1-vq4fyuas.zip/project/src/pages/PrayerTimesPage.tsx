import React, { useState, useEffect } from 'react';
import { MapPin, Calendar, Clock, RefreshCw } from 'lucide-react';

const PrayerTimesPage: React.FC = () => {
  const [location, setLocation] = useState<string>('');
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState<boolean>(false);
  const [prayerTimes, setPrayerTimes] = useState<any | null>(null);
  const [locationPermission, setLocationPermission] = useState<boolean | null>(null);
  const [nextPrayer, setNextPrayer] = useState<string>('');
  const [remainingTime, setRemainingTime] = useState<string>('');

  // Sample prayer times data (would be fetched from API in production)
  const samplePrayerTimes = {
    fajr: '05:12',
    sunrise: '06:28',
    dhuhr: '12:15',
    asr: '15:30',
    maghrib: '18:02',
    isha: '19:18',
  };

  useEffect(() => {
    // This would be replaced with actual API calls in production
    setTimeout(() => {
      setPrayerTimes(samplePrayerTimes);
      // Calculate next prayer and remaining time
      calculateNextPrayer();
    }, 1000);

    // Set up interval to update remaining time every minute
    const interval = setInterval(() => {
      if (prayerTimes) {
        calculateNextPrayer();
      }
    }, 60000);

    return () => clearInterval(interval);
  }, [prayerTimes]);

  const calculateNextPrayer = () => {
    // This is a simplified calculation - would be more complex in production
    const prayers = [
      { name: 'Fajr', time: samplePrayerTimes.fajr },
      { name: 'Sunrise', time: samplePrayerTimes.sunrise },
      { name: 'Dhuhr', time: samplePrayerTimes.dhuhr },
      { name: 'Asr', time: samplePrayerTimes.asr },
      { name: 'Maghrib', time: samplePrayerTimes.maghrib },
      { name: 'Isha', time: samplePrayerTimes.isha },
    ];

    const now = new Date();
    const currentHours = now.getHours();
    const currentMinutes = now.getMinutes();
    
    // Find next prayer
    let nextPrayerName = '';
    let remainingHours = 0;
    let remainingMinutes = 0;
    
    // For demo purposes, we'll just set Maghrib as the next prayer 
    // with a random remaining time
    nextPrayerName = 'Maghrib';
    remainingHours = 2;
    remainingMinutes = 15;
    
    setNextPrayer(nextPrayerName);
    setRemainingTime(`${remainingHours}h ${remainingMinutes}m`);
  };

  const requestLocationPermission = () => {
    setLoading(true);
    
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          // In a real app, we would use these coordinates to fetch location name
          // and prayer times from an API
          setLocationPermission(true);
          setLocation('New York, NY'); // This would be fetched based on coordinates
          setLoading(false);
        },
        (error) => {
          setLocationPermission(false);
          setLoading(false);
          console.error("Error getting location:", error);
        }
      );
    } else {
      setLocationPermission(false);
      setLoading(false);
    }
  };

  const handleLocationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setLocation(e.target.value);
  };

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setDate(e.target.value);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // In a real app, we would fetch prayer times based on location and date
    setTimeout(() => {
      setPrayerTimes(samplePrayerTimes);
      setLoading(false);
    }, 1000);
  };

  const refreshPrayerTimes = () => {
    setLoading(true);
    
    // Simulate API call to refresh prayer times
    setTimeout(() => {
      setPrayerTimes(samplePrayerTimes);
      setLoading(false);
    }, 1000);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 text-center dark:text-white">
        Prayer Times
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Location and Date Selector */}
        <div className="lg:col-span-1">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-xl font-bold mb-4 dark:text-white">
              Location Settings
            </h2>
            
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label htmlFor="location" className="block text-sm font-medium mb-2 dark:text-white">
                  Your Location
                </label>
                <div className="relative">
                  <input
                    type="text"
                    id="location"
                    className="w-full p-3 pr-10 rounded-md border border-gray-300 dark:border-gray-700 dark:bg-gray-700 dark:text-white"
                    placeholder="Enter city name"
                    value={location}
                    onChange={handleLocationChange}
                    required
                  />
                  <MapPin className="absolute right-3 top-3 text-gray-400 h-5 w-5" />
                </div>
              </div>
              
              <div className="mb-6">
                <label htmlFor="date" className="block text-sm font-medium mb-2 dark:text-white">
                  Date
                </label>
                <div className="relative">
                  <input
                    type="date"
                    id="date"
                    className="w-full p-3 pr-10 rounded-md border border-gray-300 dark:border-gray-700 dark:bg-gray-700 dark:text-white"
                    value={date}
                    onChange={handleDateChange}
                  />
                  <Calendar className="absolute right-3 top-3 text-gray-400 h-5 w-5" />
                </div>
              </div>
              
              <div className="flex space-x-4">
                <button
                  type="button"
                  className="flex-1 flex items-center justify-center py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-md transition-colors"
                  onClick={requestLocationPermission}
                  disabled={loading || locationPermission === true}
                >
                  <MapPin className="h-4 w-4 mr-2" />
                  {locationPermission === true ? 'Location Set' : 'Use My Location'}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md transition-colors"
                  disabled={loading || !location}
                >
                  Get Prayer Times
                </button>
              </div>
            </form>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h2 className="text-xl font-bold mb-4 dark:text-white">
              Calculation Method
            </h2>
            
            <div className="mb-4">
              <label htmlFor="method" className="block text-sm font-medium mb-2 dark:text-white">
                Select Method
              </label>
              <select 
                id="method" 
                className="w-full p-3 rounded-md border border-gray-300 dark:border-gray-700 dark:bg-gray-700 dark:text-white"
              >
                <option value="1">Egyptian General Authority of Survey</option>
                <option value="2">University of Islamic Sciences, Karachi</option>
                <option value="3">Islamic Society of North America (ISNA)</option>
                <option value="4">Muslim World League</option>
                <option value="5">Umm al-Qura University, Makkah</option>
              </select>
            </div>
          </div>
        </div>
        
        {/* Prayer Times Display */}
        <div className="lg:col-span-2">
          {loading ? (
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 flex justify-center items-center h-60">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
            </div>
          ) : prayerTimes ? (
            <>
              {/* Next Prayer */}
              <div className="bg-gradient-to-r from-emerald-600 to-emerald-800 rounded-lg shadow-md p-6 mb-8 text-white">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-bold">Next Prayer</h2>
                  <button 
                    onClick={refreshPrayerTimes}
                    className="p-2 rounded-full hover:bg-white/10 transition-colors"
                    aria-label="Refresh prayer times"
                  >
                    <RefreshCw className="h-5 w-5" />
                  </button>
                </div>
                
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-4xl font-bold">{nextPrayer}</p>
                    <p className="text-white/80">
                      {prayerTimes[nextPrayer.toLowerCase()] || prayerTimes.maghrib}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-white/80">Time Remaining</p>
                    <p className="text-3xl font-bold">{remainingTime}</p>
                  </div>
                </div>
              </div>

              {/* Today's Prayer Times */}
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
                <div className="p-6 border-b border-gray-200 dark:border-gray-700">
                  <h2 className="text-xl font-bold dark:text-white">Today's Prayer Times</h2>
                  <p className="text-gray-600 dark:text-gray-300">
                    {location} • {new Date(date).toLocaleDateString('en-US', { 
                      weekday: 'long', 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}
                  </p>
                </div>
                
                <div className="divide-y divide-gray-200 dark:divide-gray-700">
                  {Object.entries(prayerTimes).map(([prayer, time]) => (
                    <div 
                      key={prayer} 
                      className={`flex justify-between items-center p-6 ${
                        prayer.toLowerCase() === nextPrayer.toLowerCase() 
                          ? 'bg-emerald-50 dark:bg-emerald-900/20' 
                          : ''
                      }`}
                    >
                      <div className="flex items-center">
                        <Clock className="h-5 w-5 text-emerald-600 dark:text-emerald-400 mr-3" />
                        <span className="font-medium capitalize dark:text-white">
                          {prayer}
                        </span>
                      </div>
                      <span className="text-xl font-bold dark:text-white">{time}</span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-8 text-center">
              <MapPin className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h2 className="text-xl font-bold mb-2 dark:text-white">
                Set Your Location
              </h2>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                Please enter your location or allow location access to get accurate prayer times
              </p>
              <button
                onClick={requestLocationPermission}
                className="py-2 px-6 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md transition-colors inline-flex items-center"
              >
                <MapPin className="h-4 w-4 mr-2" />
                Use My Location
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PrayerTimesPage;
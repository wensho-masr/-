import React, { useState, useEffect } from 'react';
import { MapPin, Navigation, RefreshCw, AlertCircle } from 'lucide-react';

const QiblaPage: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [locationPermission, setLocationPermission] = useState<boolean | null>(null);
  const [qiblaDirection, setQiblaDirection] = useState<number | null>(null);
  const [currentDirection, setCurrentDirection] = useState<number | null>(null);
  const [location, setLocation] = useState<{lat: number, lng: number} | null>(null);

  // For demo purposes we'll just use a sample direction
  // In production this would be calculated based on user's location
  useEffect(() => {
    if (location) {
      // This would be a real calculation in production
      // For demo, we'll just use a fixed value
      setQiblaDirection(135); // Placeholder value
    }
  }, [location]);

  useEffect(() => {
    const handleDeviceOrientation = (event: DeviceOrientationEvent) => {
      // Alpha is the compass direction the device is facing in degrees
      const alpha = event.alpha;
      if (alpha !== null) {
        // Convert alpha to a 0-360 range and set as current direction
        setCurrentDirection(360 - alpha);
      }
    };

    if ('DeviceOrientationEvent' in window) {
      window.addEventListener('deviceorientation', handleDeviceOrientation);
    } else {
      setError('Your device does not support compass functionality');
    }

    return () => {
      window.removeEventListener('deviceorientation', handleDeviceOrientation);
    };
  }, []);

  const requestLocationPermission = () => {
    setLoading(true);
    setError(null);
    
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocationPermission(true);
          setLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
          setLoading(false);
        },
        (error) => {
          setLocationPermission(false);
          setLoading(false);
          setError('Could not access your location. Please enable location services.');
          console.error("Error getting location:", error);
        }
      );
    } else {
      setLocationPermission(false);
      setLoading(false);
      setError('Geolocation is not supported by this browser');
    }
  };

  const requestCompassPermission = () => {
    // In a real implementation, we would request device orientation permission
    // For demo purposes, we'll simulate a compass reading
    setCurrentDirection(45); // Placeholder value
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 text-center dark:text-white">
        Qibla Finder
      </h1>

      <div className="max-w-md mx-auto">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-bold mb-4 dark:text-white">
            Find Qibla Direction
          </h2>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            Allow location access to determine the direction of the Qibla from your current position.
          </p>
          
          {error && (
            <div className="p-4 mb-6 bg-red-50 dark:bg-red-900/20 border-l-4 border-red-500 rounded-md">
              <div className="flex">
                <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
                <p className="text-red-700 dark:text-red-400">{error}</p>
              </div>
            </div>
          )}
          
          <div className="flex flex-col space-y-4">
            <button
              className={`py-2 px-4 rounded-md transition-colors flex items-center justify-center ${
                locationPermission === true 
                  ? 'bg-green-600 text-white' 
                  : 'bg-blue-600 hover:bg-blue-700 text-white'
              }`}
              onClick={requestLocationPermission}
              disabled={loading || locationPermission === true}
            >
              {loading ? (
                <RefreshCw className="h-5 w-5 mr-2 animate-spin" />
              ) : (
                <MapPin className="h-5 w-5 mr-2" />
              )}
              {locationPermission === true ? 'Location Accessed' : 'Access My Location'}
            </button>
            
            <button
              className="py-2 px-4 bg-amber-600 hover:bg-amber-700 text-white rounded-md transition-colors flex items-center justify-center"
              onClick={requestCompassPermission}
              disabled={!locationPermission}
            >
              <Navigation className="h-5 w-5 mr-2" />
              Calibrate Compass
            </button>
          </div>
        </div>
        
        {/* Compass UI */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 flex flex-col items-center">
          <div className="relative w-64 h-64 mb-8">
            {/* Compass Rose */}
            <div className="absolute inset-0 rounded-full border-2 border-gray-200 dark:border-gray-700">
              {/* Cardinal Points */}
              <div className="absolute top-1 left-1/2 -translate-x-1/2 text-center">
                <div className="text-lg font-bold dark:text-white">N</div>
              </div>
              <div className="absolute right-1 top-1/2 -translate-y-1/2 text-center">
                <div className="text-lg font-bold dark:text-white">E</div>
              </div>
              <div className="absolute bottom-1 left-1/2 -translate-x-1/2 text-center">
                <div className="text-lg font-bold dark:text-white">S</div>
              </div>
              <div className="absolute left-1 top-1/2 -translate-y-1/2 text-center">
                <div className="text-lg font-bold dark:text-white">W</div>
              </div>
            </div>
            
            {/* Compass Needle */}
            <div 
              className="absolute inset-0 flex items-center justify-center"
              style={{ transform: `rotate(${currentDirection || 0}deg)` }}
            >
              <div className="h-56 w-2 bg-gradient-to-b from-red-600 to-gray-400 rounded-full"></div>
            </div>
            
            {/* Qibla Direction Indicator */}
            {qiblaDirection && (
              <div 
                className="absolute inset-0 flex items-center justify-center"
                style={{ transform: `rotate(${qiblaDirection}deg)` }}
              >
                <div className="absolute top-0 left-1/2 -translate-x-1/2 transform -translate-y-3">
                  <div className="w-6 h-6 bg-emerald-600 rounded-full flex items-center justify-center text-white">
                    K
                  </div>
                </div>
              </div>
            )}
            
            {/* Center Point */}
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-gray-800 dark:bg-white"></div>
          </div>
          
          <div className="text-center">
            {qiblaDirection ? (
              <>
                <p className="text-xl font-bold mb-2 dark:text-white">
                  Qibla Direction: {qiblaDirection.toFixed(0)}°
                </p>
                <p className="text-gray-600 dark:text-gray-300">
                  Rotate your device until the needle points to K
                </p>
              </>
            ) : (
              <p className="text-gray-600 dark:text-gray-300">
                Please enable location and compass to find Qibla direction
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default QiblaPage;
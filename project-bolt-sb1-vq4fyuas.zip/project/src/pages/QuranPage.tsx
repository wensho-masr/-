import React, { useState, useEffect } from 'react';
import { Search, ChevronDown, ChevronUp, BookOpen } from 'lucide-react';

const QuranPage: React.FC = () => {
  const [surahs, setSurahs] = useState<any[]>([]);
  const [selectedSurah, setSelectedSurah] = useState<number | null>(null);
  const [selectedVerse, setSelectedVerse] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);
  const [verses, setVerses] = useState<any[]>([]);

  useEffect(() => {
    // Fetch surahs list
    const fetchSurahs = async () => {
      try {
        const response = await fetch('https://api.alquran.cloud/v1/surah');
        const data = await response.json();
        
        if (data.code === 200) {
          setSurahs(data.data);
        } else {
          setError('Failed to load Surah list');
        }
        
        setLoading(false);
      } catch (err) {
        setError('Error fetching Quran data');
        setLoading(false);
      }
    };

    fetchSurahs();
  }, []);

  const handleSurahSelect = async (surahNumber: number) => {
    setSelectedSurah(surahNumber);
    setSelectedVerse(null);
    setLoading(true);
    
    try {
      const response = await fetch(`https://api.alquran.cloud/v1/surah/${surahNumber}/ar.alafasy`);
      const data = await response.json();
      
      if (data.code === 200) {
        setVerses(data.data.ayahs);
      } else {
        setError('Failed to load Surah verses');
      }
      
      setLoading(false);
    } catch (err) {
      setError('Error fetching verses');
      setLoading(false);
    }
  };

  const handleVerseClick = (verseNumber: number) => {
    setSelectedVerse(verseNumber === selectedVerse ? null : verseNumber);
  };

  const filteredSurahs = surahs.filter(surah => 
    surah.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    surah.englishName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    surah.number.toString().includes(searchQuery)
  );

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 text-center dark:text-white">
        The Noble Quran
      </h1>

      {/* Search and dropdown */}
      <div className="mb-8">
        <div className="relative">
          <div className="flex items-center mb-4">
            <input
              type="text"
              placeholder="Search surah by name or number..."
              className="w-full p-3 rounded-md border border-gray-300 dark:border-gray-700 dark:bg-gray-800 dark:text-white"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Search className="absolute right-3 text-gray-400 h-5 w-5" />
          </div>
          
          <div className="relative">
            <button 
              className="w-full p-3 rounded-md bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 flex justify-between items-center dark:text-white"
              onClick={() => setShowDropdown(!showDropdown)}
            >
              {selectedSurah ? 
                surahs.find(surah => surah.number === selectedSurah)?.englishName || 'Select Surah' : 
                'Select Surah'
              }
              {showDropdown ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
            </button>
            
            {showDropdown && (
              <div className="absolute z-10 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-md shadow-lg max-h-60 overflow-y-auto">
                {loading ? (
                  <p className="p-3 text-center dark:text-white">Loading...</p>
                ) : error ? (
                  <p className="p-3 text-center text-red-500">{error}</p>
                ) : filteredSurahs.length === 0 ? (
                  <p className="p-3 text-center dark:text-white">No surahs found</p>
                ) : (
                  filteredSurahs.map(surah => (
                    <button
                      key={surah.number}
                      className={`w-full p-3 text-left hover:bg-gray-100 dark:hover:bg-gray-700 ${
                        selectedSurah === surah.number ? 'bg-emerald-50 dark:bg-emerald-900' : ''
                      } dark:text-white`}
                      onClick={() => {
                        handleSurahSelect(surah.number);
                        setShowDropdown(false);
                      }}
                    >
                      <span className="font-semibold">{surah.number}.</span> {surah.englishName} ({surah.name})
                    </button>
                  ))
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Quran Content */}
      {selectedSurah && (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          {loading ? (
            <div className="flex justify-center items-center h-40">
              <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-emerald-600"></div>
            </div>
          ) : error ? (
            <p className="text-center text-red-500">{error}</p>
          ) : (
            <>
              {/* Surah header */}
              <div className="text-center mb-8 pb-6 border-b border-gray-200 dark:border-gray-700">
                <h2 className="text-2xl font-bold mb-2 dark:text-white">
                  {surahs.find(surah => surah.number === selectedSurah)?.englishName}
                </h2>
                <h3 className="text-3xl font-arabic mb-4 dark:text-white">
                  {surahs.find(surah => surah.number === selectedSurah)?.name}
                </h3>
                <p className="text-gray-600 dark:text-gray-300">
                  {verses.length} Verses • {surahs.find(surah => surah.number === selectedSurah)?.revelationType}
                </p>
              </div>

              {/* Bismillah except for Surah 9 */}
              {selectedSurah !== 9 && (
                <div className="text-center mb-8">
                  <p className="text-2xl font-arabic dark:text-white">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</p>
                </div>
              )}

              {/* Verses */}
              <div className="space-y-6">
                {verses.map((verse) => (
                  <div 
                    key={verse.number} 
                    className={`p-4 rounded-md ${
                      selectedVerse === verse.numberInSurah ? 'bg-emerald-50 dark:bg-emerald-900/20' : ''
                    }`}
                    onClick={() => handleVerseClick(verse.numberInSurah)}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <span className="bg-emerald-600 text-white w-8 h-8 rounded-full flex items-center justify-center">
                        {verse.numberInSurah}
                      </span>
                      <div className="flex space-x-2">
                        <button className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
                          <BookOpen className="h-5 w-5" />
                        </button>
                      </div>
                    </div>
                    
                    <p 
                      className="text-2xl font-arabic text-right leading-loose mb-4 dark:text-white" 
                      dir="rtl"
                    >
                      {verse.text}
                    </p>
                    
                    {selectedVerse === verse.numberInSurah && (
                      <div className="pt-4 border-t border-gray-200 dark:border-gray-700 mt-4">
                        <p className="text-gray-700 dark:text-gray-300">
                          <strong>Translation:</strong> [Translation would be fetched from API]
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default QuranPage;